﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_Entity;
using Car_Exception;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace Car_DAL
{
    public class CarDal
    {
        public bool AddCarDetails(CarDetail objCar)
        {
            bool employeeAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[InsertCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter incidentId = new SqlParameter("@ID", objCar.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", objCar.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", objCar.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", objCar.Airbags);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.price);

                objCom.Parameters.Add(incidentId);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeAdded;

        }
        public bool UpdateCarDAL(CarDetail objCar)
        {
            bool carUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[UpdateCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter incidentId = new SqlParameter("@ID", objCar.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", objCar.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", objCar.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", objCar.Airbags);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.price);

               
                //
                objCon.Open();
                objCom.Parameters.Add(incidentId);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                objCom.ExecuteNonQuery();
                carUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(int id)
        {
            bool carDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[DeleteCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", id);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                carDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carDeleted;
        }
        public CarDetail SearchCarDAL(int id)
        {
            CarDetail objCar = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[SearchCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", SqlDbType.Int);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId",SqlDbType.Int);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", SqlDbType.VarChar,50);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", SqlDbType.Int);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", SqlDbType.VarChar,50);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", SqlDbType.Int);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", SqlDbType.Int);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", SqlDbType.Int);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", SqlDbType.Int);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", SqlDbType.VarChar,50);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", SqlDbType.VarChar, 50);
                //
                objSqlParam_Id.Direction = ParameterDirection.Input;
                objSqlParam_ManufacturerId.Direction = ParameterDirection.Output;
                objSqlParam_Model.Direction = ParameterDirection.Output;
                objSqlParam_Type.Direction = ParameterDirection.Output;
                objSqlParam_Engine.Direction = ParameterDirection.Output;
                objSqlParam_BHP.Direction = ParameterDirection.Output;
                objSqlParam_Transmission.Direction = ParameterDirection.Output;
                objSqlParam_Mileage.Direction = ParameterDirection.Output;
                objSqlParam_Seats.Direction = ParameterDirection.Output;
                objSqlParam_Airbag.Direction = ParameterDirection.Output;
                objSqlParam_BootSpace.Direction = ParameterDirection.Output;
                objSqlParam_Price.Direction = ParameterDirection.Output;
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                //
                //
                objSqlParam_Id.Value = id;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objCar = new CarDetail();
                objCar.Id = id;
                objCar.ManufacturerId =  Convert.ToInt32(objSqlParam_ManufacturerId.Value);
                objCar.Model = (objSqlParam_Model.Value) as string;
                objCar.Type = Convert.ToInt32(objSqlParam_Type.Value);
                objCar.Transmission = Convert.ToInt32 (objSqlParam_Transmission.Value) ;
                objCar.Mileage = Convert.ToInt32(objSqlParam_Mileage.Value);
                objCar.BHP = Convert.ToInt32(objSqlParam_BHP.Value);
                objCar.Engine = (objSqlParam_Engine.Value) as string;
                objCar.Airbags = (objSqlParam_Airbag.Value) as string;
                objCar.BootSpace = (objSqlParam_BootSpace.Value) as string;
                objCar.price = (objSqlParam_Price.Value) as string;
                objCar.Seats = Convert.ToInt32(objSqlParam_Seats.Value);
            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCar;
        }


        public DataTable GetManufacturer()
        {
            DataTable manufacturerList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[GetManufacturer]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                manufacturerList = new DataTable();
                manufacturerList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return manufacturerList;
        }
        public DataTable GetCarType()
        {
            DataTable CarTypeList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[GetCarType]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTypeList = new DataTable();
                CarTypeList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTypeList;
        }
        public DataTable GetCarTransmission()
        {
            DataTable CarTransmissionList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[GetTransmission]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTransmissionList = new DataTable();
                CarTransmissionList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTransmissionList;
        }
        public List<CarDetail> GetAllCarDetails()
        {
            List<CarDetail> cars = new List<CarDetail>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("[46008173].[GetAllCars]", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    CarDetail car1 = new CarDetail();
                    car1.Id = Convert.ToInt32(objDR[0]);
                    car1.Model = (objDR[1]) as string;
                    car1.ManufacturerId = Convert.ToInt32(objDR[2]);
                    car1.Type = Convert.ToInt32(objDR[3]);
                    car1.Engine = (objDR[4]) as string;
                    car1.BHP = Convert.ToInt32(objDR[5]);
                    car1.Transmission = Convert.ToInt32(objDR[6]);
                    car1.Mileage = Convert.ToInt32(objDR[7]);
                    car1.Seats = Convert.ToInt32(objDR[8]);
                    car1.Airbags = (objDR[9]) as string;
                    car1.BootSpace = (objDR[10]) as string;
                    car1.price = (objDR[11]) as string;
                    cars.Add(car1);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return cars;
        }

    }
}
