﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_DAL;
using Car_Entity;
using Car_Exception;

namespace Car_BAL
{
    public class CarBal
    {
        public  bool AddCar(CarDetail car)
        {
            bool CarAdded = false;
            try
            {
                    CarDal carDal = new CarDal();
                    CarAdded = carDal.AddCarDetails(car);

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public  bool DeleteCarBL(int carId)
        {
            bool carDeleted = false;
            try
            {
                if (carId > 0)
                {
                    CarDal carDal = new CarDal();
                    carDeleted = carDal.DeleteCarDAL(carId);
                }
                else
                {
                    throw new CarException("Employee Id must be greater than 0.");
                }
            }
            catch (CarException Cex)
            {
                throw Cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }
        public  bool UpdateCarBL(CarDetail car)
        {
            bool carUpdated = false;
            try
            {
               
                {
                    CarDal carDal = new CarDal();
                    carUpdated = carDal.UpdateCarDAL(car);
                   
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }
        public  CarDetail SearchCarBL(int carId)
        {
            CarDetail objCar = null;
            try
            {
                if (carId > 0)
                {
                    CarDal carDal = new CarDal();
                    objCar = carDal.SearchCarDAL(carId);
                }
                else
                {
                    throw new CarException("Employee Id must be greater than 0.");
                }
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objCar;
        }

        public  DataTable GetManufacturerBL()
        {
            DataTable ManufacturerList;
            try
            {
                CarDal carDAL = new CarDal();
                ManufacturerList = carDAL.GetManufacturer();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ManufacturerList;
        }
        public DataTable GetCarTypeBL()
        {
            DataTable CarTypeList;
            try
            {
                CarDal carDAL = new CarDal();
                CarTypeList = carDAL.GetCarType(); ;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTypeList;
        }
        public DataTable GetCarTransmissionBL()
        {
            DataTable CarTransmissionList;
            try
            {
                CarDal carDAL = new CarDal();
                CarTransmissionList = carDAL.GetCarTransmission(); 
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTransmissionList;
        }
        public  List<CarDetail> GetAllRequest()
        {
            List<CarDetail> carList = null;
            try
            {
                CarDal DAL = new CarDal();
                carList = DAL.GetAllCarDetails();   //getallrequest in dal is accessed
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carList;
        }
    }
}
